

<?php $__env->startSection('title'); ?>
Desaku Cart Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content page-cart">
    <section class="store-breadcrumbs" data-aos="fade-down" data-aos-delay="100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="/index.html">Home</a>
                            </li>
                            <li class="breadcrumb-item active">
                                Cart
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section>

    <section class="store-cart">
        <div class="container">
            <div class="row" data-aos="fade-up" data-aos-delay="100">
                <div class="col-12 table-responsive">
                    <table class="table table-borderless table-cart">
                        <thead>
                            <tr>
                                <td>Image</td>
                                <td>Name &amp; Seller</td>
                                <td>Price</td>
                                <td>Menu</td>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $totalPrice = 0
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td style="width: 20%;">
                                    <?php if($cart->product->galleries->count()): ?>
                                    <img src="<?php echo e(Storage::url($cart->product->galleries->first()->photos)); ?>" alt=""
                                        class="cart-image ">

                                    <?php else: ?>

                                    <?php endif; ?>
                                </td>
                                <td style="width: 35%;">
                                    <div class="product-title"><?php echo e($cart->product->name); ?></div>
                                    <div class="product-subtitle"><?php echo e($cart->product->user->store_name); ?></div>
                                </td>
                                <td style="width: 35%;">
                                    <div class="product-title"> <?php echo e(number_format($cart->product->price )); ?></div>
                                    <div class="product-subtitle">Rp</div>
                                </td>
                                <td style="width: 20%;">
                                    <form action="<?php echo e(route('cart-delete',$cart->id)); ?>" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-remove-cart">X</button>
                                    </form>
                                </td>
                            </tr>
                            <?php
                            $totalPrice += $cart->product->price
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            Data Kosong

                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row" data-aos="fade-up" data-aos-delay="150">
                <div class="col-12">
                    <hr>
                </div>
                <div class="col-12">
                    <h2 class="mb-4"> Lokasi COD</h2>
                </div>
            </div>


            <form action="<?php echo e(route('checkout')); ?>" id="locations" enctype="multipart/form-data" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden"  name="total_price" value=<?php echo e($totalPrice); ?>>
                <div class="row mb-2" data-aos="fade-up" data-aos-delay="200">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="address_one">Detail Lokasi 1</label>
                            <input type="text" class="form-control" id="address_one" name="address_one"
                              >
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="address_two">Detail Lokasi 2</label>
                            <input type="text" class="form-control" id="address_two" name="address_two"
                              >
                        </div>
                    </div>
                    

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="phone_number">No Telpon</label>
                            <input type="text" class="form-control" id="phone_number" name="phone_number"
                                value="<?php echo e(Auth::user()->phone_number); ?>">
                        </div>
                    </div>

                </div>

                <div class="row" data-aos="fade-up" data-aos-delay="150">
                    <div class="col-12">
                        <hr>
                    </div>
                    <div class="col-12">
                        <h2 class="mb-1"> Informasi Biaya </h2>
                    </div>
                </div>

                <div class="row" data-aos="fade-up" data-aos-delay="200">
                    
                    <div class="col-4 col-md-2">
                        <div class="product-title text-success"><?php echo e(number_format($totalPrice ?? 0)); ?></div>
                        <div class="product-subtitle">Total</div>
                    </div>
                    <div class="col-8 col-md-3">
                        <button type="submit" class="btn btn-success mt-4 px-4 btn-block"> Checkout Now</button>
                    </div>
                </div>
            </form>

        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('addon-script'); ?>
<script src="/vendor/vue/vue.js"></script>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<script>
  var locations = new Vue({
    el: "#locations",
    mounted() {
       AOS.init();
      this.getProvincesData();
    },
    data: {
      provinces: null,
      regencies: null,
      provinces_id: null,
      regencies_id: null,
    },
    methods: {
      getProvincesData(){ 
        var self = this;
        axios.get('<?php echo e(route('api-provinces')); ?>')
        .then(function(response){
            self.provinces = response.data;
        })
      },

      getRegenciesData(){
        var self = this;
        axios.get('<?php echo e(url('api/regencies')); ?>/' + self.provinces_id)
        .then(function(response){
            self.regencies = response.data;
        })
      },

    },
    watch:{
        provinces_id: function(val, oldVal){
            this.regencies_id = null;
            this.getRegenciesData();
        }
    }
  });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desaku\resources\views/pages/cart.blade.php ENDPATH**/ ?>