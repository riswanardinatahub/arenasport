<?php $__env->startSection('content'); ?>
<div class="page-content page-auth" >
    <div class="section-store-auth" data-aos="fade-up">
      <div class="container">
        <div class="row align-items-center justify-content-center row-login ">
          <div class="col-12 col-lg-8">
            <h2>Silahkan Daftarkan Diri Anda</h2>
            
            <form class="mt-3" method="POST" action="<?php echo e(route('register')); ?>">
               <?php echo csrf_field(); ?>
              <div class="row">
                <div class="col-lg-6" id="register">
                      <div class="form-group">
                        <label for="">Full Name</label>
                        <input id="name" v-model="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                          value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="form-group">
                        <label for="">No Telpon</label>
                        <input id="phone_number" v-model="phone_number" type="text" class="form-control <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone_number"
                          value="<?php echo e(old('phone_number')); ?>" required autocomplete="phone_number" autofocus>
                        <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      
                      <div class="form-group">
                        <label for="">Email Address</label>
                        <input type="email" name="email" @change="checkForEmail()" class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                          :class="{ 'is-invalid' : this.email_unavailable }" aria-describedby="emailHelp" placeholder="Masukan Email"
                          v-model="email" autocomplete="email" />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      
                      <div class="form-group">
                        <label for="">Password</label>
                        <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                          required autocomplete="new-password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      
                      <div class="form-group">
                        <label for="">Konfirmasi Password</label>
                        <input id="password_confirmation" type="password"
                          class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" required
                          autocomplete="new-password">
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                       <button type="submit" :disabled="this.email_unavailable" class="btn btn-success btn-block mt-4">
                  Sign Up Now
                </button>

              <a href="<?php echo e(route('login')); ?>" class="btn btn-signup btn-block  mt-2">
                Back To Sign In
              </a>
                      
                      <div class="form-group">
                        <label for="">Store</label>
                        <p class="text-muted">Apakah anda juga ingin membuka toko?</p>
                        <div class="custom-control custom-radio custom-control-inline">
                          <input type="radio" class="custom-control-input" name="is_store_open" id="openStoreTrue" v-model="is_store_open"
                            :value="true">
                          <label for="openStoreTrue" class="custom-control-label">Iya, Boleh</label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                          <input type="radio" class="custom-control-input" name="is_store_open" id="openStoreFalse" v-model="is_store_open"
                            :value="false">
                          <label for="openStoreFalse" class="custom-control-label">Enggak, Makasih</label>
                        </div>
                      </div>
                      
                      <div class="form-group" v-if="is_store_open">
                        <label for="">Nama Toko</label>
                        <input type="text" v-model="store_name" id="store_name" class="form-control <?php $__errorArgs = ['store_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                          name="store_name" required autocomplete autofocus>
                        <?php $__errorArgs = ['store_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      
                      <div class="form-group" v-if="is_store_open">
                        <label for="">Kategori</label>
                        <select name="categories_id" id="" class="form-control">
                          <option value="" disabled>Select Category</option>
                          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                </div>
                
                <div class="col-lg-6" id="locations">
                    <div class="form-group">
                      <div class="form-group">
                        <label for="provinces_id">Province</label>
                        <select name="provinces_id" id="provinces_id" class="form-control" v-if="provinces" v-model="provinces_id">
                          <option v-for="province in provinces" :value="province.id">{{ province.name }}</option>
                        </select>
                        <select v-else class="form-control"></select>
                      </div>
                    </div>

                    <div class="form-group">
                      <label for="regencies_id">Kabupaten</label>
                      <select name="regencies_id" id="regencies_id" class="form-control" v-if="regencies"
                        v-model="regencies_id">
                        <option v-for="regency in regencies" :value="regency.id">{{ regency.name }}</option>
                      </select>
                      <select v-else class="form-control"></select>
                    </div>

                    <div class="form-group">
                      <label for="districts_id">Kecamatan/Kelurahan</label>
                      <select name="districts_id" id="districts_id" class="form-control" v-if="districts"
                        v-model="districts_id">
                        <option v-for="district in districts" :value="district.id">{{ district.name }}</option>
                      </select>
                      <select v-else class="form-control"></select>
                    </div>

                    <div class="form-group">
                      <label for="villages_id">Desa</label>
                      <select name="villages_id" id="villages_id" class="form-control" v-if="villages"
                        v-model="villages_id">
                        <option v-for="village in villages" :value="village.id">{{ village.name }}</option>
                      </select>
                      <select v-else class="form-control"></select>
                    </div>
           
                </div>
                
              </div>

              
            </form>
          </div>
          
        </div>
      </div>
    </div>
  </div>






<?php $__env->stopSection(); ?>


<?php $__env->startPush('addon-script'); ?>
   <script src="/vendor/vue/vue.js"></script>
  <script src="https://unpkg.com/vue-toasted"></script>
  <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
  <script>
    Vue.use(Toasted);
    var register = new Vue({
      el: '#register',
      mounted() {
        AOS.init();
       
      },
      methods:{
          checkForEmail: function(){
            var self = this;
            axios.get('<?php echo e(route('api-register-check')); ?>', {
                params: {
                  email: self.email
                }
              })
              .then(function (response) {
                // Handle Success
                if(response.data == "Available"){
                      self.$toasted.show(
                        "Email Anda Tersedia,Silahkan lanjutkan langkah pendaftaran.",
                        {
                          position: "top-center",
                          className: "rounded",
                          duration: 1000,
                        }
                      );
                      self.email_unavailable = false ;
                }else{
                      
                      self.$toasted.error(
                        "Maaf, tampaknya email sudah terdaftar pada sistem kami.",
                        {
                          position: "top-center",
                          className: "rounded",
                          duration: 1000,
                        }
                      );
                      self.email_unavailable = true;
                }
                console.log(response);
              })
              
          }
        },
      data() {
          return{
            name: "",
            email: "",
            is_store_open: true,
            store_name: "",
            email_unavailable:false
          }
        },
    });
  </script>

 <script>
  var locations = new Vue({
    el: "#locations",
    mounted() {
      AOS.init();
      this.getProvincesData();
    },
    data: {
      provinces: null,
      regencies: null,
      districts: null,
      villages: null,
      provinces_id: null,
      regencies_id: null,
      districts_id: null,
      villages_id: null,
    },
    methods: {
      getProvincesData() {
        var self = this;
        axios.get('<?php echo e(route('api-provinces')); ?>')
          .then(function (response) {
            self.provinces = response.data;
          })
      },

      getRegenciesData() {
        var self = this;
        axios.get('<?php echo e(url('api/regencies')); ?>/' + self.provinces_id)
          .then(function (response) {
            self.regencies = response.data;
          })
      },

      getDistrictsData() {
        var self = this;
        axios.get('<?php echo e(url('api/districts')); ?>/' + self.regencies_id)
          .then(function (response) {
            self.districts = response.data;
          })
      },

      getVillagesData() {
        var self = this;
        axios.get('<?php echo e(url('api/villages')); ?>/' + self.districts_id)
          .then(function (response) {
            self.villages = response.data;
          })
      },

    },
    watch: {
      provinces_id: function (val, oldVal) {
        this.regencies_id = null;
        this.getRegenciesData();
      },

      regencies_id: function (val, oldVal) {
        this.districts_id = null;
        this.getDistrictsData();
      },

      districts_id: function (val, oldVal) {
        this.villages_id = null;
        this.getVillagesData();
      }
    }
  });

</script>
 
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desaku\resources\views/auth/register.blade.php ENDPATH**/ ?>