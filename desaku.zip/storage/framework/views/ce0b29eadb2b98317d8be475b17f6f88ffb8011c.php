<footer class="bottom-0">
    <div class="container">
      <div class="row ">
        <div class="col-12 text-center">
          <p class="pt-3 pb-3 bg-success rounded">
            2021 Copyright Store. ALl Rights Reserved.
          </p>
        </div>
      </div>
    </div>
  </footer>
<?php /**PATH C:\laragon\www\desaku\resources\views/includes/footer.blade.php ENDPATH**/ ?>