  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
  <link href="/style/main.css" rel="stylesheet" />
  <script src="https://kit.fontawesome.com/58cfd4d2e0.js" crossorigin="anonymous"></script><?php /**PATH C:\laragon\www\desaku\resources\views/includes/style.blade.php ENDPATH**/ ?>