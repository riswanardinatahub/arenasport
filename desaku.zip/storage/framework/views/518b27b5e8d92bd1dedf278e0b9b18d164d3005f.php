

<?php $__env->startSection('title'); ?>
Store Dashboard Transactions Details Pages
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section-content section-dashboard-home" data-aos="fade-up">
  <div class="container-fluid">
    <div class="dashboard-heading">
      <h2 class="dashboard-title">
        <?php echo e($transaction->code); ?>

      </h2>
      <p class="dashboard-subtitle">
        Transactions Details
      </p>
    </div>
    <div class="dashboardcontent" id="transactionDetails">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-12 col-md-4">
                  <img src="<?php echo e(Storage::url($transaction->product->galleries->first()->photos ?? '')); ?>"
                    class="w-100 mb-3" alt="">
                </div>
                <div class="col-12 col-md-8">
                  <div class="row">
                    <div class="col-12 col-md-6">
                      <div class="product-title">
                        Customer Name
                      </div>
                      <div class="product-subtitle">
                        <?php echo e($transaction->transaction->user->name); ?>

                      </div>
                    </div>
                      <div class="col-12 col-md-6">
                      <div class="product-title">
                        Nama Penjual
                      </div>
                      <div class="product-subtitle">
                        <?php echo e($transaction->product->user->name); ?>

                      </div>
                    </div>
                    <div class="col-12 col-md-6">
                      <div class="product-title">
                        Nama Produk
                      </div>
                      <div class="product-subtitle">
                        <?php echo e($transaction->product->name); ?>

                      </div>
                    </div>
                    <div class="col-12 col-md-6">
                      <div class="product-title">
                        Date of Transaction
                      </div>
                      <div class="product-subtitle">
                        <?php echo e($transaction->created_at); ?>

                      </div>
                    </div>
                    <div class="col-12 col-md-6">
                      <div class="product-title">
                        Trsansaction Status
                      </div>
                      
                      <?php if($transaction->transaction->transaction_status == 'SUCCESS' AND $transaction->transaction->status_transaction_customer == 'SUCCESS'): ?>
                       <div class="product-subtitle text-success">
                        SUCCESS
                         </div>
                        <?php else: ?>
                          <div class="product-subtitle text-danger">
                        PENDING
                         </div>
                      <?php endif; ?>





                
                      
                
                     </div>
                    <div class="col-12 col-md-6">
                      <div class="product-title">
                        Total Amount
                      </div>
                      <div class="product-subtitle ">
                        <?php echo e($transaction->price); ?>

                      </div>
                    </div>

                    <?php if(Auth::user()->id == $transaction->product->users_id): ?>
                      <div class="col-12 col-md-6">
                      <div class="product-title">
                        No Telpon Pembeli
                      </div>
                      <div class="product-subtitle ">
                        <?php echo e($transaction->transaction->user->phone_number); ?>  <a target="_blank" href="https://api.whatsapp.com/send?text=Hallo saya dokter <?php echo e($transaction->product->name); ?>&phone=<?php echo e($transaction->transaction->user->phone_number); ?>" type="button" class="btn btn-success btn-sm">Chat</a>
                      </div>

                      <?php if($transaction->transaction->transaction_status == 'SUCCESS'): ?>
                        <button disabled type="button" class="btn btn-success btn-sm">Selesai</button>
                      <?php else: ?>
                        <a href="/konfirmasistatuspenjual/<?php echo e($transaction->transaction->id); ?>" class="btn btn-warning">Konfrimasi Transasksi</a>
                      <?php endif; ?>
                      


                    </div>

                    <?php else: ?>
                      <div class="col-12 col-md-6">
                      <div class="product-title">
                        No Telpon Penjual
                      </div>
                      <div class="product-subtitle ">
                         <?php echo e($transaction->product->user->phone_number); ?> <a target="_blank" href="https://api.whatsapp.com/send?text=Hallo saya dokter <?php echo e($transaction->product->name); ?>&phone=<?php echo e($transaction->transaction->user->phone_number); ?>" type="button" class="btn btn-success btn-sm">Chat</a>
                      </div>

                      <?php if($transaction->transaction->status_transaction_customer == 'SUCCESS'): ?>
                        <button disabled type="button" class="btn btn-success btn-sm">Selesai</button>
                      <?php else: ?>
                        <a href="/konfirmasistatuscustomer/<?php echo e($transaction->transaction->id); ?>" class="btn btn-warning">Konfrimasi Transasksi</a>
                      <?php endif; ?>
                       
                    </div>
                    <?php endif; ?>
                    
                    
                  </div>
                </div>
              </div>
              <form action="<?php echo e(route('dashboard-transaction-update', $transaction->id)); ?>" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
                <div class="row">
                  <div class="col-12 mt-4">
                    <h5>Shipping Information</h5>
                  </div>
                  <div class="col-12">
                    <div class="row">
                      <div class="col-12 col-md-6">
                        <div class="product-title">
                          Address I
                        </div>
                        <div class="product-subtitle">
                          <?php echo e($transaction->transaction->user->address_one); ?>

                        </div>
                      </div>
                      <div class="col-12 col-md-6">
                        <div class="product-title">
                          Address II
                        </div>
                        <div class="product-subtitle">
                          <?php echo e($transaction->transaction->user->address_two); ?>

                        </div>
                      </div>
                      <div class="col-12 col-md-6">
                        <div class="product-title">
                          Province
                        </div>
                        <div class="product-subtitle">
                          <?php echo e(App\Models\Province::find($transaction->transaction->user->provinces_id)->name); ?>

                        </div>
                      </div>
                      <div class="col-12 col-md-6">
                        <div class="product-title">
                          City
                        </div>
                        <div class="product-subtitle">
                         <?php echo e(App\Models\Regency::find($transaction->transaction->user->regencies_id)->name); ?>

                        </div>
                      </div>
                      <div class="col-12 col-md-6">
                        <div class="product-title">
                          Postal Code
                        </div>
                        <div class="product-subtitle">
                         <?php echo e($transaction->transaction->user->zip_code); ?>

                        </div>
                      </div>
                      <div class="col-12 col-md-6">
                        <div class="product-title">
                          Country
                        </div>
                        <div class="product-subtitle">
                         <?php echo e($transaction->transaction->user->country); ?>

                        </div>
                      </div>
                      
                    </div>
                  </div>
                </div>
                <div class="row text-right">
                  
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('addon-script'); ?>

<script src="/vendor/vue/vue.js"></script>
<script>
  var transactionDetails = new Vue({
    el: '#transactionDetails',
    data: {
      status: "<?php echo e($transaction->shipping_status); ?>",
      resi: "<?php echo e($transaction->resi); ?>",
    },
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desaku\resources\views/pages/dashboard-transactions-details.blade.php ENDPATH**/ ?>