

<?php $__env->startSection('title'); ?>
Detail Rangking
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<br>
<br>
<br>
<br>

<section class="store-name">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-12 text-center">
                <div class="d-flex justify-content-center flex-row bd-highlight">

                    <div class="p-1 bd-highlight">
                        <h2> Daftar Rangking Penjualan Produk Desa</h2>
                    </div>
                </div>


            </div>
        </div>
    </div>
</section>

<section class="store-name mt-3" style="height: 100vh;">
    <div class="container">
        <div class="row justify-content-center">


            <div class="col-5 text-center mt-2">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">Desa</th>
                            <th scope="col">Ranking</th>
                            <th scope="col">Jumlah Transaksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no =0;
                        $test =1;
                        ?>
                        <?php $__currentLoopData = $occurences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $no++;
                        $datadesa = App\Models\Village::find($x)
                        ?>
                        <tr>
                            <td><?php echo e($datadesa->name); ?></td>
                            <td><?php echo e($test++); ?></td>
                            <td><?php echo e($val); ?></td>
                        </tr>

                        <?php if($no == 5): ?>
                        <?php break; ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </tbody>
                </table>




            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desaku\resources\views/detailrangking.blade.php ENDPATH**/ ?>