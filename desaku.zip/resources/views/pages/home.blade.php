@extends('layouts.app')

@section('title')
Desaku
@endsection

@section('content')
<div class="page-content page-home">
    <!-- Carusel Section -->
    <section class="store-carousel" data-aos="fade-up">
        <div class="container">
            <div class="row">
                <div class="col-lg-12" data-aos="zoom-in">
                    <div id="storeCarousel" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li class="active" data-target="#storeCarousel" data-slide-to="0">
                            </li>
                            <li data-target="#storeCarousel" data-slide-to="1">
                            </li>
                            <li data-target="#storeCarousel" data-slide-to="2">
                            </li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="/images/banner2.jpg" alt="Carousel Img" class="d-block w-100">
                            </div>
                            <div class="carousel-item ">
                                <img src="/images/banner1.jpg" alt="Carousel Img" class="d-block w-100">
                            </div>
                            <div class="carousel-item ">
                                <img src="/images/banner3.jpg" alt="Carousel Img" class="d-block w-100">
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="store-name">
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-12 text-center">
                    <div class="d-flex justify-content-center flex-row bd-highlight">
                        <div class="p-2 bd-highlight"><img src="/images/ceklis.svg" alt=""></div>
                        <div class="p-1 bd-highlight">
                            <h2> Official store</h2>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>

     <section class="store-name">
        <div class="container">
            <div class="row justify-content-center">
                            {{-- @php
                                $no =0;
                            @endphp
                            @foreach ($occurences as $x => $val )

                            @php
                            $no++;
                                $datadesa = App\Models\Village::find($x)
                            @endphp
                     
                                {{ $x = $val  }} jumlah count
                                {{ $x   }} id desan
                                {{ $datadesa->name }}

                                @if ($no == 5)
                                    @break
                                @endif
                            @endforeach --}}
            
                <div class="col-5 text-center mt-2">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                        <th scope="col">Desa</th>
                        <th scope="col">Ranking</th>
                        </tr>
                    </thead>
                    <tbody>
                     @php
                        $no =0;
                        $test =1;
                     @endphp
                    @foreach ($occurences as $x => $val )
                            @php
                                $no++;
                                $datadesa = App\Models\Village::find($x)
                            @endphp
                        <tr>
                            <td>{{ $datadesa->name }}</td>
                            <td><img src="/images/bintang{{ $test++ }}.png" alt=""></td>
                        </tr>
                        
                        @if ($no == 5)
                            @break
                        @endif
                    @endforeach
                        

                       
                    </tbody>
                    </table>
                    <a href="/rank" class="btn btn-success"> Cek Detail</a>


                        {{-- <div class="">
                            <h5> <img src="/images/bintang1.png" alt=""> Desa Sukapura</h5>
                        </div>
                    
                        <div class="">
                             <h5> <img src="/images/bintang2.png" alt="">  Desa Tanjung</h5>
                        </div>

                        <div class="">
                            <h5> <img src="/images/bintang3.png" alt="">  Desa Tinum</h5>
                        </div>

                        <div class="">
                            <h5> <img src="/images/bintang4.png" alt="">  Desa Tinum</h5>
                        </div>

                        <div class="">
                            <h5> <img src="/images/bintang5.png" alt="">  Desa Tinum</h5>
                        </div> --}}
                </div>
            </div>
        </div>
    </section>

    <!-- Store Trend Categori -->
    <section class="store-trend-categories">
        <div class="container">
            <div class="row">
                <div class="col-12" data-aos="fade-up">
                    <h5>Kategori</h5>
                </div>
            </div>
            <div class="row">

                @php
                $incrementCategory = 0
                @endphp

                @forelse ($categories as $category)
                <div class="col-6 col-md-3 col-lg-2" data-aos="fade-up" data-aos-delay="{{ $incrementCategory+= 100 }}">
                    <a href="{{ route('categories-detail', $category->slug) }}"
                        class="component-categories d-block text-center ">
                        <div class="categories-image  ">
                            <img src="{{ Storage::url($category->photo) }}" alt="" class="img-fluid">
                        </div>
                    </a>
                    <p class="fw-bold text-center">
                        {{ $category->name }}
                    </p>
                </div>
                @empty
                <div class="col-12 text-center py-5" data-aos="fade-up" data-aos-delay="100">
                    Data Tidak Di Temukan
                </div>
                @endforelse




            </div>
        </div>
    </section>

    <!-- Store new Produk -->
    <section class="store-new-products mt-3">
        <div class="container">
            <div class="row">
                <div class="col-12" data-aos="fade-up">
                    <h5>Produk Terbaru</h5>

                    {{-- @php
                    $kamu = '3204270006';
                        
                        $sumber = 'http://desaku.id/api/productvillage/'.+$kamu;
                        $konten = file_get_contents($sumber);
                        $data = json_decode($konten, true);
                    @endphp

                    @foreach ($data as $aku)
                        {{ $aku['name'] }}                        
                    @endforeach --}}
                </div>
            </div>
            <div class="row">
                @php
                $incrementProduct = 0
                @endphp
                @forelse ( $products as $product)
                <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="{{ $incrementProduct+=100 }}">
                    <a href="{{ route('detail', $product->slug) }}" class="component-products d-block">
                        <div class="products-thumbnail">
                            <div class="products-image" style="
                             @if ($product->galleries->count())
                                background-image: url('{{ Storage::url($product->galleries->first()->photos) }}')
                             @else
                                background-image: #eee
                             @endif 
                            ">
                            </div>
                        </div>
                        <div class="products-text">
                            {{ $product->name }}
                            @auth
                            @if($product->users_id == Auth::user()->id)
                            <small class="text-success"> Your Product
                            </small>
                            @else

                            @endif
                            @endauth



                        </div>
                        <div class="products-price">
                            <span class="text-dark">RP.</span> {{ number_format($product->price) }}
                        </div>
                    </a>
                </div>

                @empty

                @endforelse
            </div>
        </div>
    </section>


    <!-- Store new Produk -->
    <section class="store-new-products mt-3">
        <div class="container">
            <div class="row">
                <div class="col-12" data-aos="fade-up">
                    <h5>Poduk Terlaris</h5>
                </div>
            </div>
            <div class="row">
                @foreach ($produkterlaris as $data)
                    @php
                        $product = App\Product::find($data->id_produk)
                    @endphp
                 <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="100">
                    <a href="{{ route('detail', $product->slug) }}" class="component-products d-block">
                         <div class="products-thumbnail">
                            <div class="products-image" style="
                             @if ($product->galleries->count())
                                background-image: url('{{ Storage::url($product->galleries->first()->photos) }}')
                             @else
                                background-image: #eee
                             @endif 
                            ">
                            </div>
                        </div>
                        <div class="products-text">
                            {{ $product->name }}
                        </div>
                        <div class="products-price">
                            <span class="text-dark">RP.</span> {{ number_format($product->price, 0, ',', '.')  }}
                            <p class="text-success w-15"> ( <span> {{ $data->jumlah_terjual }} </span>) Produk Terjual  </p>
                        </div>
                    </a>
                </div>
                
                @endforeach
                
               
               
            </div>
        </div>
    </section>
</div>

@endsection